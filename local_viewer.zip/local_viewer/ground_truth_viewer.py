import argparse
import json
import numpy as np
import open3d as o3d
from pyquaternion import Quaternion
from nuscenes.nuscenes import NuScenes
from nuscenes.utils.data_classes import LidarPointCloud
from nuscenes.utils.geometry_utils import transform_matrix
from pathlib import Path

CLASS_NAMES = [
    'car', 'truck', 'construction_vehicle', 'bus', 'trailer',
    'barrier', 'motorcycle', 'bicycle', 'pedestrian', 'traffic_cone'
]

def get_class_color_map():
    named_colors = [
        ("red", [1.0, 0.0, 0.0]),
        ("pink", [1.0, 0.75, 0.8]),
        ("blue", [0.0, 0.0, 1.0]),
        ("brown", [0.6, 0.3, 0.0]),
        ("magenta", [1.0, 0.0, 1.0]),
        ("yellow", [1.0, 1.0, 0.0]),
        ("orange", [1.0, 0.5, 0.0]),
        ("purple", [0.5, 0.0, 0.5]),
        ("black", [0.0, 0.0, 0.0]),
        ("gray", [0.5, 0.5, 0.5]),
    ]
    return named_colors

def get_class_index(category_name):
    for idx, name in enumerate(CLASS_NAMES):
        if name in category_name:  # use `in` instead of `startswith`
            return idx
    print(f"Warning: {category_name} not found in CLASS_NAMES.")
    return -1 


def create_o3d_box(box, color):
    corners = box.corners().T
    lines = [
        [0, 1], [1, 2], [2, 3], [3, 0],
        [4, 5], [5, 6], [6, 7], [7, 4],
        [0, 4], [1, 5], [2, 6], [3, 7]
    ]
    line_set = o3d.geometry.LineSet()
    line_set.points = o3d.utility.Vector3dVector(corners)
    line_set.lines = o3d.utility.Vector2iVector(lines)
    line_set.colors = o3d.utility.Vector3dVector([color for _ in lines])
    return line_set


def visualize_sample(nusc, sample):
    lidar_token = sample['data']['LIDAR_TOP']
    lidar_data = nusc.get('sample_data', lidar_token)
    lidar_filepath = nusc.get_sample_data_path(lidar_token)

    pc = LidarPointCloud.from_file(lidar_filepath)
    points = pc.points[:3, :].T
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points)

    # Get transformations
    cs_record = nusc.get('calibrated_sensor', lidar_data['calibrated_sensor_token'])
    pose_record = nusc.get('ego_pose', lidar_data['ego_pose_token'])

    # Prepare color map
    color_map = get_class_color_map()

    o3d_boxes = []
    print("\nClass to Color Mapping:")

    for ann_token in sample['anns']:
        ann = nusc.get('sample_annotation', ann_token)
        class_idx = get_class_index(ann['category_name'])
        color = color_map[class_idx % len(color_map)][1] if class_idx >= 0 else [1.0, 1.0, 1.0]
        class_name = ann['category_name']
        color_name = color_map[class_idx % len(color_map)][0] if class_idx >= 0 else "Unknown"
        
        # Print class and color
        print(f"{class_name}: {color_name} ({color})")

        # Get box and transform it
        box = nusc.get_box(ann_token)
        box = transform_box_to_lidar(box, pose_record, cs_record)

        # Create Open3D box and add to the list
        o3d_box = create_o3d_box(box, color)
        o3d_boxes.append(o3d_box)

    o3d.visualization.draw_geometries([pcd] + o3d_boxes)


def transform_box_to_lidar(box, pose_record, cs_record):
    # Transform box from global to ego vehicle frame
    box.translate(-np.array(pose_record['translation']))
    box.rotate(Quaternion(pose_record['rotation']).inverse)

    # Then from ego vehicle to LiDAR frame
    box.translate(-np.array(cs_record['translation']))
    box.rotate(Quaternion(cs_record['rotation']).inverse)
    return box


def main():
    parser = argparse.ArgumentParser(description="Visualize a nuScenes scene with Open3D.")
    parser.add_argument("--input_dir", type=str, required=True, help="Path to the nuScenes dataset root.")
    parser.add_argument("--pred_json", type=str, required=True, help="Path to the *_pred.json file.")
    args = parser.parse_args()

    # Load token from JSON file
    with open(args.pred_json, 'r') as f:
        pred_data = json.load(f)
    token = pred_data['token']

    # Initialize NuScenes
    nusc = NuScenes(version='v1.0-mini', dataroot=args.input_dir, verbose=True)

    # Get sample from token
    sample = nusc.get('sample', token)

    # Visualize
    visualize_sample(nusc, sample)


if __name__ == "__main__":
    main()
