import argparse
import json
from pathlib import Path

import open3d as o3d
import numpy as np

CLASS_NAMES = [
    'car', 'truck', 'construction_vehicle', 'bus', 'trailer',
    'barrier', 'motorcycle', 'bicycle', 'pedestrian', 'traffic_cone'
]


def get_class_color_map():
    named_colors = [
        ("red", [1.0, 0.0, 0.0]),
        ("black", [0.0, 0.0, 0.0]),
        ("blue", [0.0, 0.0, 1.0]),
        ("brown", [0.6, 0.3, 0.0]),
        ("magenta", [1.0, 0.0, 1.0]),
        ("yellow", [1.0, 1.0, 0.0]),
        ("orange", [1.0, 0.5, 0.0]),
        ("purple", [0.5, 0.0, 0.5]),
        ("pink", [1.0, 0.75, 0.8]),
        ("gray", [0.5, 0.5, 0.5]),
    ]
    return named_colors


def get_label_name(label_id):
    if 1 <= label_id <= len(CLASS_NAMES):
        return CLASS_NAMES[label_id - 1]
    else:
        return f"Unknown({label_id})"


def draw_boxes(vis, boxes, scores, labels):
    unique_labels = sorted(set(labels))
    color_map = get_class_color_map()

    if len(unique_labels) > len(color_map):
        print(f"[Warning] More classes ({len(unique_labels)}) than available colors ({len(color_map)}). Colors will repeat.")

    label_to_color = {}
    for i, label in enumerate(unique_labels):
        color_name, rgb = color_map[i % len(color_map)]
        label_to_color[label] = (color_name, rgb)

    print("\nColor Mapping:")
    for label in unique_labels:
        class_name = get_label_name(label)
        color_name = label_to_color[label][0]
        print(f"  {class_name}: {color_name}")

    for i, box in enumerate(boxes):
        center = box[:3]
        size = box[3:6]
        yaw = box[6]

        R = o3d.geometry.get_rotation_matrix_from_xyz([0, 0, yaw])
        obb = o3d.geometry.OrientedBoundingBox(center, R, size)
        obb.color = label_to_color[labels[i]][1]
        vis.add_geometry(obb)


def visualize_scene(ply_file, json_file):
    pcd = o3d.io.read_point_cloud(str(ply_file))

    with open(json_file, 'r') as f:
        pred = json.load(f)

    # NEW: Extract and print sample_token if it exists
    sample_token = pred.get("sample_token", None)
    if sample_token:
        print(f"\n🟢 Sample token from prediction: {sample_token}")
    else:
        print("\n🔴 No sample_token found in prediction JSON.")

    boxes = np.array(pred["boxes"])
    scores = np.array(pred["scores"])
    labels = np.array(pred["labels"])

    vis = o3d.visualization.Visualizer()
    vis.create_window()
    vis.add_geometry(pcd)

    draw_boxes(vis, boxes, scores, labels)

    vis.run()
    vis.destroy_window()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input_dir', type=str, required=True, help='Path to saved output folder, e.g. velodyne_000008')
    parser.add_argument('--sample', type=str, default='sample_000', help='Sample name prefix, e.g. sample_000')
    args = parser.parse_args()

    input_path = Path(args.input_dir)
    ply_file = input_path / f"{args.sample}.ply"
    json_file = input_path / f"{args.sample}_pred.json"

    visualize_scene(ply_file, json_file)


if __name__ == '__main__':
    main()
